import { Directive, ElementRef, HostListener, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appCompFailure]',
  standalone: true
})
export class CompFailureDirective 
{

  constructor(private obj : ElementRef, private renderer : Renderer2) 
  { }

  @HostListener('mouseover') onMouseOver()
  {
    this.obj.nativeElement.style.color = 'red';
  }

  @HostListener('mouseout') onMouseOut()
  {
    this.obj.nativeElement.style.color = 'grey';
  }
}
