import { Directive, ElementRef, HostListener, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appCompSuccess]',
  standalone: true
})
export class CompSuccessDirective 
{

  constructor(private obj : ElementRef, private renderer : Renderer2) 
  {}

  @HostListener('mouseover') onMouseOver()
  {
    this.obj.nativeElement.style.color = 'green';
  }

  @HostListener('mouseout') onMouseOut()
  {
    this.obj.nativeElement.style.color = 'grey';
  }
}
