import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StringService {

  constructor() { }

  CountCapital(str: string): number {
    let count = 0;
    for (let char of str) {
      if (char >= 'A' && char <= 'Z') {
        count++;
      }
    }
    return count;
  }
}
