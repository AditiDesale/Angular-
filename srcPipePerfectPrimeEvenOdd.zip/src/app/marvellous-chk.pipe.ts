import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'marvellousChk',
  standalone: true
})
export class MarvellousChkPipe implements PipeTransform 
{
  transform(value : number, Param  :string) : any
  {
    if (Param == "Prime")
    {
      if (value <= 1) 
      {
        return "It is not a prime number";
      }
      for (let i = 2; i <= Math.sqrt(value); i++) 
      {
        if (value % i === 0) 
        {
          return "It is not a prime number";
        }
      }
      return "It is prime number";
    }

    if (Param == "Perfect")
    {
      let sum = 0;
      for (let i = 1; i <= value / 2; i++) 
      {
        if (value % i === 0) 
        {
          sum += i;
        }
      }
      if (sum === value)
      {
        return "It is perfect number";
      }
      else
      {
        return "It is not perfect number";
      }
    }

    if (Param == "Even")
    {
      if ((value % 2) == 0)
      {
        return "It is even Number";
      }
      else
      {
        return "It is not even number";
      }
    }

    if (Param == "Odd")
    {
      if ((value % 2) !== 0)
      {
        return "It is odd number";
      }
      else
      {
        return "It is not odd number";
      }
    }
  }

}
