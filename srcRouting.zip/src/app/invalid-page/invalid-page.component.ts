import { Component } from '@angular/core';

@Component({
  selector: 'app-invalid-page',
  standalone: true,
  imports: [],
  templateUrl: './invalid-page.component.html',
  styleUrl: './invalid-page.component.css'
})
export class InvalidPageComponent {

}
