import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ArithmaticService } from '../arithmatic.service';

@Component({
  selector: 'app-demo',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './demo.component.html',
  styleUrl: './demo.component.css',
  providers : [ArithmaticService]
})
export class DemoComponent
{
  addition : number = 0; 
  substraction : number = 0;

  constructor(private obj : ArithmaticService) 
  {
    this.addition = this.obj.Add(5,3);
    this.substraction = this.obj.Sub(10,4);
  }
}
