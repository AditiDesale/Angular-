import { outputAst } from '@angular/compiler';
import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrl: './child.component.css'
})
export class ChildComponent 
{
    @Input() parentMessage : string = '';
    @Output() onMessageChange = new EventEmitter<string>();

    sendMessage() : void
    {
      this.onMessageChange.emit('Hello from Child!');
    }
}
