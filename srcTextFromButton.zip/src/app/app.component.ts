import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent 
{
    childData : string = '';

    receiveData(data : string) : void
    {
      this.childData = data;
    }
}
