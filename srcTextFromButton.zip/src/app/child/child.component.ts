import { Component, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrl: './child.component.css'
})
export class ChildComponent 
{
    inputText : string = '';

    @Output() onDataChange = new EventEmitter<string>();

    sendData() : void
    {
      this.onDataChange.emit(this.inputText);
    }
}
